<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- Bootstrap   -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
  integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

  <!-- Font Awesome   -->
  <script src="https://kit.fontawesome.com/ac2760b985.js" crossorigin="anonymous"></script>
  <!-- Slick Slider   -->
  <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>

  <title>Protect Pet</title>

  <!-- Custom style   -->
  <link rel="stylesheet" href="./css/style.css"/>


</head>

<body>
  <!--   <img src="./images/WebBackground.jpg"/>  -->
  <!-- header section   -->
  <header>
    <div class="container">
      <div class="row">

        <div class="col-md-3 col-sm-8 col-8">
          <img src="./images/WebsiteLogo.png" alt="WebsiteLogo.png" width="200" height="80"/>
        </div>

        <div class="col-md-5 col-sm-16 col-16">
          <!-- column size for medium size devices| column size for small size devices |specifies 6 column width to div tag-->
          <div class="btn-group">
            <button
            class="btn dropdown-toggle my-md-4 my-4 text-black"
            style="background-color: var(--grey300);"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
            >Resources</button><!-- my=margin y md=(prefix)medium   -->
          <div class="dropdown-menu" style="background-color: var(--grey300);">
            <a href="#" class="dropdown-item">Adopt</a>
            <a href="#" class="dropdown-item">Rescue</a>
            <a href="#" class="dropdown-item">About pet</a>
          </div>
          </div>
        </div>

        <div class="col-md-4 col-12 text-right">
          <p class="my-md-4 header-links">
            <a href="signup.php" target="_blank" class="px-2">Sign Up</a>
            <a href="login.php" target="_blank" class="px-1">Log In</a>
          </p>
        </div>

      </div>
    </div>

    <!-- container-fluid start-->
    <div class="container-fluid p-0">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">

        <button
        class="navbar-toggler" type="button"
        data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
        aria-controls="navbarNavDropdown" aria-expanded="false"
        aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav mb-auto">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle"
              data-toggle="dropdown" href="#"
              id="navbarDropdownMenuLink"
              role="button" aria-expanded="false">Adopt</a>
              <ul class="dropdown-menu bg-light" aria-labelledby="navbarDropdownMenuLink" >
                <li><a class="dropdown-item" href="adoptcat.html" target="_blank">Adopt a cat</a></li>
                <li><a class="dropdown-item" href="adoptdog.html" target="_blank">Adopt a dog</a></li>
                <li><a class="dropdown-item" href="#">Adopt a bird</a></li>
              </ul>
            </li>
          </ul>
        </div>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav mb-auto ">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle"
              data-toggle="dropdown" href="#"
              id="navbarDropdownMenuLink"
              role="button" aria-expanded="false">Pets</a>
              <ul class="dropdown-menu bg-light" aria-labelledby="navbarDropdownMenuLink" >
                <li><a class="dropdown-item" href="#">Find pet</a></li>
                <li><a class="dropdown-item" href="#">Lost pet</a></li>
                <li><a class="dropdown-item" href="#">Post for adoption</a></li>
                <li><a class="dropdown-item" href="#">Post for lost pet</a></li>
              </ul>
            </li>
          </ul>
        </div>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav mb-auto">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle"
              data-toggle="dropdown" href="#"
              id="navbarDropdownMenuLink"
              role="button" aria-expanded="false">Rescue</a>
              <ul class="dropdown-menu bg-light" aria-labelledby="navbarDropdownMenuLink" >
                <li><a class="dropdown-item" href="#">Rescue animal</a></li>
                <li><a class="dropdown-item" href="#">Post for rescue</a></li>
              </ul>
            </li>
          </ul>
        </div>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav mb-auto">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle"
              data-toggle="dropdown" href="#"
              id="navbarDropdownMenuLink"
              role="button" aria-expanded="false">Pet food</a>
              <ul class="dropdown-menu bg-light" aria-labelledby="navbarDropdownMenuLink" >
                <li><a class="dropdown-item" href="foodstore.html" target="_blank">Food shops</a></li>
                <li><a class="dropdown-item" href="#">Food habits</a></li>
              </ul>
            </li>
          </ul>
        </div>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav mb-auto">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle"
              data-toggle="dropdown" href="#"
              id="navbarDropdownMenuLink"
              role="button" aria-expanded="false">Veterinary Help</a>
              <ul class="dropdown-menu bg-light" aria-labelledby="navbarDropdownMenuLink" >
                <li><a class="dropdown-item" href="veterinaryhospitals.html" target="_blank">Veterinary hospitals</a></li>
                <li><a class="dropdown-item" href="clinics.html" target="_blank">Clinics</a></li>
                <li><a class="dropdown-item" href="#">Vets</a></li>
                <li><a class="dropdown-item" href="medicalstore.html" target="_blank">Medicine stores</a></li>
                <li><a class="dropdown-item" href="#">Vaccines</a></li>
                <li><a class="dropdown-item" href="#">Pet care</a></li>
              </ul>
            </li>
          </ul>
        </div>

        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav mb-auto">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#">News Article</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">About us</a>
            </li>
          </ul>
        </div>

        <div class="navbar-nav">
          <li class="nav-item mx-2 search-icon">
            <i class="fas fa-search"></i>
          </li>
        </div>

      </nav>
    </div>
    <!-- container-fluid end-->

</header>

<!-- main section   -->
  <main>
    <!-- First Slider   -->
    <div class="container-fluid p-0">
      <div class="site-slider">

        <div class="slider-one">
          <div>
            <img src="./images/Slider3.jpg" class="img-fluid" alt="Banner 3" height="550px" width="1400px">
          </div>
          <div>
            <img src="./images/Slider4.jpg" class="img-fluid" alt="Banner 4" height="550px" width="1400px">
          </div>
          <div>
            <img src="./images/Slider5.jpg" class="img-fluid" alt="Banner 5" height="550px" width="1400px">
          </div>
        </div>

        <div class="slider-btn">
          <span class="prev position-top"><i class="fas fa-chevron-left"></i></span>
          <span class="next position-top right-0"><i class="fas fa-chevron-right"></i></span>
        </div>

      </div>
    </div>
    <!-- Grid cards   -->
    <div class="container">

      <div class="row row-cols-1 row-cols-md-2 my-5 g-4">

        <div class="col">
          <div class="card h-100">
            <img src="./images/CardPet.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Pets</h5>
              <p class="card-text">Find a pet. Post for adoption. Bring a pet new home.</p>
              <a href="#" class="btn btn-primary">Pets</a>
            </div>

            <ul class="list-group list-group-flush">
              <a href="#" class="list-group-item">Find pet</a>
              <a href="#" class="list-group-item">Post for adoption</a>
              <a href="#" class="list-group-item">Search for lost pet</a>
              <a href="#" class="list-group-item">Post for lost pet</a>
            </ul>

          </div>
        </div>

        <div class="col">
          <div class="card ">
            <img src="./images/CardRescue.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Rescue</h5>
              <p class="card-text">Rescue animal, save life.</p>
              <a href="#" class="btn btn-primary">Rescue</a>
            </div>

            <ul class="list-group list-group-flush">
              <a href="#" class="list-group-item">Rescue animal</a>
              <a href="#" class="list-group-item">Post for rescue</a>
            </ul>

          </div>
        </div>

        <div class="col">
          <div class="card">
            <img src="./images/CardFood.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Pet food</h5>
              <p class="card-text">Find pet food shops. Learn about pet foods.</p>
              <a href="#" class="btn btn-primary">Pet food</a>
            </div>

            <ul class="list-group list-group-flush">
              <a href="foodstore.html" target="_blank" class="list-group-item">Food shops</a>
              <a href="#" class="list-group-item">Food habits</a>
            </ul>

          </div>
        </div>

      </div>

      <div class="row row-cols-1 row-cols-md-2 my-4 g-4">
        <div class="col">
          <div class="card h-100">
            <img src="./images/CardVeterinary.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Veterinary help</h5>
              <p class="card-text">Take your pet to veterian. Search for vets. Know about vaccines.</p>
              <a href="#" class="btn btn-primary">Veterinary help</a>
            </div>

            <ul class="list-group list-group-flush">
              <a href="veterinaryhospitals.html" target="_blank" class="list-group-item">Veterinary hospitals</a>
              <a href="clinics.html" target="_blank" class="list-group-item">Vet clinics</a>
              <a href="#" class="list-group-item">Vets</a>
              <a href="medicalstore.html" target="_blank" class="list-group-item">Medicine stores</a>
              <a href="#" class="list-group-item">Vaccines</a>
              <a href="#" class="list-group-item">Pet care</a>
            </ul>

          </div>
        </div>

        <div class="col">
          <div class="card">
            <img src="./images/CardNews.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Articles</h5>
              <p class="card-text">Learn about helpful insights.</p>
              <a href="#" class="btn btn-primary">Articles</a>
            </div>
          </div>
        </div>

      </div>
    </div>


    <!-- Second Slider
    <div class="container-fluid">
      <div class="site-slider-two px-md-4">
        <div class="row">

          <div class="col-md-2 option pt-md-5 pt-4"></div>

        </div>
      </div>
    </div> -->

  </main>


  <footer>
    <div class="content">
      <div class="container p-3">

        <div class="row p-0">

          <div class="col h-100">
            <div class="d-flex flex-column text-black pt-4">
              <a href="#">Home</a>
              <a href="#">About us</a>
              <!-- <h5 class="d-inline-flex">text here</h5> -->
              <a href="#">Services</a>
              <a href="#">FAQ</a>

            </div>
          </div>

          <div class="col col-md-5 h-100">
            <div class="text-black pt-4">
            <h5 class="d-inline-flex">Newslatter</h5>
            <input type="text" placeholder="Email" class="p-2 ml-3 border-0" size="40"><button type="button" class="py-2 btn-info bg-light text-dark border-0">Subscribe</button>
            </div>
          </div>

          <div class="col h-100">
            <div class="text-black pt-4 h-100">
            <h5 class="d-inline-flex">Connect with us</h5>
            <div class="d-flex flex-row">
              <img src="./images/facebook-f.svg" alt="" height="25" class="p-1">
              <img src="./images/twitter-brands.svg" alt="" height="25" class="p-1">
              <img src="./images/instagram-brands.svg" alt="" height="25" class="p-1">
            </div>
          </div>
          </div>

        </div>

      </div>

      <div class="text-center text-black w-100 p-1">
        <p>@2021 protectpet.com    All rights reserved template design by ####</p>
      </div>

    </div>
  </footer>

<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="./js/main.js"></script>
  </body>
  </html>
