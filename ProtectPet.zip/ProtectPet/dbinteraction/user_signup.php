<?php

	require 'database/connection.php';

	if (isset($_POST['signup'])) {
    $firstname = $_POST['user_firstname'];
    $lastname = $_POST['user_lastname'];
    $phone = $_POST['user_phone'];
    $email = $_POST['user_email'];
    $username = $_POST['user_username'];
    $password = $_POST['user_password'];
    $gender = $_POST['user_gender'];


    $sql1 = "SELECT * FROM users
            WHERE phone = $phone";
    $checkphone = mysqli_num_rows( mysqli_query($conn, $sql1) );
		if($checkphone == 1){
				echo "<script>alert('Phone number already exists! Please try with another number.')</script>";
		}

    $sql2 = "SELECT * FROM users
            WHERE email = $email";
    $checkemail = mysqli_num_rows( mysqli_query($conn, $sql2) );
		if($checkemail == 1){
				echo "<script>alert('Email already exists! Please enter another email.')</script>";
		}

    $sql3 = "SELECT * FROM users
            WHERE username = $username";
    $checkusername = mysqli_num_rows( mysqli_query($conn, $sql3) );
		if($checkusername == 1){
				echo "<script>alert('Username already exists!')</script>";
		}


    // Validate password strength
    $uppercase = preg_match('@[A-Z]@', $password);
    $lowercase = preg_match('@[a-z]@', $password);
    $number    = preg_match('@[0-9]@', $password);
    $specialChars = preg_match('@[^\w]@', $password);

    if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
        echo 'Password should be at least 8 characters in length with combination of upper case, lower case, number and special character.';
    }

    if($password != $confirmpassword){
				echo "<script>alert('Please enter correct password to confirm.')</script>";
		}

    else{
      $sql4 = "INSERT INTO users(username, fname, lname, email, phone, password)
               VALUES ('$username', '$firstname', '$lastname', '$email', '$phone', '$password')";

      $is_inserted = mysqli_query($conn, $sql4);
      if($is_inserted){
        echo 'Account has been created successfully!';
      }
    }
  }
else{
  echo '404 not found!';
}
?>
