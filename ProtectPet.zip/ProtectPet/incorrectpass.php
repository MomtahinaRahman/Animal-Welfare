<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        h1{
            font-family: monospace;
            text-align: center;
        }
    </style>
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/form.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">


</head>
<body>

  <header>
    <div class="container">
      <div class="row">

        <div class="col-md-3 col-sm-8 col-8">
          <img src="./images/WebsiteLogo.png" alt="WebsiteLogo.png" width="200" height="80"/>
        </div>

        <div class="col-md-5 col-sm-16 col-16">
          <!-- column size for medium size devices| column size for small size devices |specifies 6 column width to div tag-->
          <div class="btn-group">
            <button
            class="btn dropdown-toggle my-md-4 my-4 text-black"
            style="background-color: var(--grey300);"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
            >Resources</button><!-- my=margin y md=(prefix)medium   -->
          <div class="dropdown-menu" style="background-color: var(--grey300);">
            <a href="#" class="dropdown-item">Adopt</a>
            <a href="#" class="dropdown-item">Rescue</a>
            <a href="#" class="dropdown-item">About pet</a>
          </div>
          </div>
        </div>

        <div class="col-md-4 col-12 text-right">
          <p class="my-md-4 header-links">
            <a href="signup.html" target="_blank" class="px-2">Sign Up</a>
            <a href="#" class="px-1"><b>Log In</b></a>
          </p>
        </div>

      </div>
    </div>


</header>

<div class="container mt-4 col-5">
    <h5 class="text-danger">Wrong email address or password. Try again!</h5>
<form  action="login.php" method="post">
      <!--Email address :<input type="text" name="email_address" required><br>
      Password : <input type="email" name="password" required><br>
      <input type="submit" name="login" value="Login">-->
    </form>

      <form action="user_login.php" method="post">
        <!--
        <div class="imgcontainer">
          <img src="./images/UserProfileLogo.png" alt="Avatar" class="avatar">
        </div>
      -->

        <div class="container mt-4">
          <label for="exampleInputEmail1" class="form-label">Email address</label>
          <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email_address" required>
          <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>


          <label for="exampleInputPassword1" class="form-label">Password</label>
          <input type="password" class="form-control" id="exampleInputPassword1" name="password" required><br>
          <input type="submit" name="login" value="Login">
          

          <label>
            <input type="checkbox" checked="checked" name="remember"> Remember me
          </label>
        </div>

<!--
        <div class="ml-1 form-check">
          <input type="checkbox" class="form-check-input" id="exampleCheck1">
          <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div> -->

        <div class="container" style="background-color:#f1f1f1">
          <button type="button" class="cancelbtn">Cancel</button>
          <span class="psw"> <a href="#">Forgot password?</a></span>
        </div>

        </form>

</div>

        <script src="https://kit.fontawesome.com/657ba0d3d3.js" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js"></script>
        <script src="https://cdn.js.cloudfare.com/ajax/libs/tether/1.4.0/js/tether.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


</body>
</html>
