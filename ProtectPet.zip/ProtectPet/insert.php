<?php
require 'connection.php';

if(isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['phone']) && isset($_POST['email_address']) && isset($_POST['username']) && isset($_POST['password']) && isset($_POST['confirm_pass']) && isset($_POST['gender']) ){
  $fname   =  $_POST['fname'];
  $lname =   $_POST['lname'];
  $phone   =  $_POST['phone'];
  $email_address =   $_POST['email_address'];
  $username   =  $_POST['username'];
  $password =   $_POST['password'];
  $confirm_pass   =  $_POST['confirm_pass'];
  $gender =   $_POST['gender'];

  $sql = "INSERT INTO users (fname,lname,phone,email_address,username,password,confirm_pass,gender)
        values('$fname', '$lname','$phone','$email_address','$username','$password','$confirm_pass','$gender')";

  $is_inserted = mysqli_query($conn,$sql );

  if($is_inserted){
    echo 'Successfully Sign up!';
  }else{
    echo 'Opps error!';
  }

}else{
  echo '404 not found!';
}
	
?>