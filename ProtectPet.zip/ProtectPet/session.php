<?php
   include('connection.php');
   session_start();
   
   $user_check = $_SESSION['login_user'];
   $sql = "SELECT email_address FROM users WHERE email_address = '$user_check'";
   $ses_sql = mysqli_query($conn,$sql);
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   
   $login_session = $row['email_address'];
   
   if(!isset($_SESSION['login_user'])){
      header("location:login.php");
      die();
   }
?>